package com.howtodoinjava.demo.jsonsimple;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadFullJson {

	public static void main(String[] args) {
		JSONParser jsonParser = new JSONParser();

		try (FileReader reader = new FileReader("Bp_Menu.json")) {
			Object obj = jsonParser.parse(reader);

			JSONArray array = (JSONArray) (((JSONObject) (((JSONObject) obj).get("body"))).get("items"));

			LinkedHashMap<String, String> mp = new LinkedHashMap<>();
			for (Object o : array) {
				String item = (String) ((JSONObject) o).get("id");
				JSONArray value = (JSONArray) ((JSONObject) ((JSONObject) ((JSONObject) o).get("taxLabelInfo"))
						.get("defaultValue")).get("labels");

				if (value.contains("TEMP_HEATED")) {
					mp.put(item, "TEMP_HEATED");
				} else if (value.contains("TEMP_UNHEATED")) {
					mp.put(item, "TEMP_UNHEATED");
				} else if (value.contains("TEMP_COLD")) {
					mp.put(item, "TEMP_COLD");
				} else {
					System.out.println(item + "======>" + "Nothing is found about TEMP");
				}

			}

			// Blank workbook
			XSSFWorkbook workbook = new XSSFWorkbook();

			// Create a blank sheet
			XSSFSheet sheet = workbook.createSheet("Products");

			Set<String> keyset = mp.keySet();
			int rownum = 0;
			for (String key : keyset) {
				Row row = sheet.createRow(rownum++);

				Cell cell0 = row.createCell(0);
				cell0.setCellValue(key);
				Cell cell1 = row.createCell(1);
				cell1.setCellValue(mp.get(key));
			}
			try {
				// Write the workbook in file system
				FileOutputStream out = new FileOutputStream(new File("Temp.xlsx"));
				workbook.write(out);
				out.close();

				System.out.println("Temp.xlsx written successfully on disk.");
			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
}
