package com.howtodoinjava.demo.jsonsimple;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ReadJSONExample {
	public static void main(String[] args) {
		JSONParser jsonParser = new JSONParser();

		try (FileReader reader = new FileReader("employees.json")) {
			Object obj = jsonParser.parse(reader);

			String item = (String)((JSONObject) obj).get("id");
			JSONArray value =(JSONArray) ((JSONObject) ((JSONObject)((JSONObject) obj).get("taxLabelInfo"))
					.get("defaultValue")).get("labels");

			System.out.println(item+"======>"+value.get(2));

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

}
