package com.howtodoinjava.demo.jsonsimple;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadFullJson {

	public static void main(String[] args) {
		JSONParser jsonParser = new JSONParser();

		try (FileReader reader = new FileReader("Bp_Menu.json")) {
			Object obj = jsonParser.parse(reader);

			JSONArray array = (JSONArray) (((JSONObject) (((JSONObject) obj).get("body"))).get("items"));

			
			List<String> list1=new ArrayList<String>();
			List<String> list2=new ArrayList<String>();
			List<String> list3=new ArrayList<String>();
			List<Long> list4=new ArrayList<Long>();
			List<String> list5=new ArrayList<String>();
			List<Long> list6=new ArrayList<Long>();
			List<String> list7=new ArrayList<String>();
			int i=0;
			for (Object o : array) {
				
				String id = (String) ((JSONObject) o).get("id");
				String description = (String) ((JSONObject) ((JSONObject) ((JSONObject) o).get("description"))
						.get("translations")).get("en");

				JSONArray temp = (JSONArray) ((JSONObject) ((JSONObject) ((JSONObject) o).get("taxLabelInfo"))
						.get("defaultValue")).get("labels");

				String name = (String) ((JSONObject) ((JSONObject) ((JSONObject) o).get("title"))
						.get("translations")).get("en");
				
				Long alc = (Long) ((JSONObject) ((JSONObject) ((JSONObject) o).get("dishInfo"))
						.get("classifications")).get("alcoholicItems");
				
				Long price =  (Long) ((JSONObject) ((JSONObject) o).get("priceInfo"))
						.get("price");
				
				
				JSONObject a=(JSONObject) ((JSONObject) o).get("modifierGroupIds");
				JSONArray bottle;
				if(a!=null) {
					bottle =  (JSONArray) ((JSONObject) ((JSONObject) o).get("modifierGroupIds"))
							.get("ids");
					//System.out.println(bottle);
					if(description!="") {
						list6.add(price);
						
						String bo=bottle.toString();
						System.out.println(bo);
						String fee=bo.substring(13,18);
						System.out.println(fee);
						
						list7.add(fee);
						list1.add(id);
						list2.add(name);
						list3.add(description);
						list4.add(alc);
						if (temp.contains("TEMP_HEATED")) {
							list5.add("TEMP_HEATED");
						} else if (temp.contains("TEMP_UNHEATED")) {
							list5.add("TEMP_UNHEATED");
						} else if (temp.contains("TEMP_COLD")) {
							list5.add("TEMP_COLD");
						} else {
							list5.add("Nothing is found about TEMP");
						}
					}
				}
				
				
				
				

			}

			// Blank workbook
			XSSFWorkbook workbook = new XSSFWorkbook();

			// Create a blank sheet
			XSSFSheet sheet = workbook.createSheet("Products");

			
			int rownum = 0;
			for (String st : list1) {
				Row row = sheet.createRow(rownum++);

				Cell cell0 = row.createCell(0);
				cell0.setCellValue(list2.get(i));
				Cell cell1 = row.createCell(1);
				cell1.setCellValue(list3.get(i));
				Cell cell2 = row.createCell(2);
				cell2.setCellValue(list5.get(i));
				Cell cell3 = row.createCell(3);
				cell3.setCellValue(list4.get(i));
				Cell cell4 = row.createCell(4);
				cell4.setCellValue(list1.get(i));
				Cell cell5 = row.createCell(5);
				cell5.setCellValue(list6.get(i));
				Cell cell6 = row.createCell(6);
				cell6.setCellValue(list7.get(i));
				i++;
			}
			try {
				// Write the workbook in file system
				FileOutputStream out = new FileOutputStream(new File("Temp3.xlsx"));
				workbook.write(out);
				out.close();

				System.out.println("Temp.xlsx written successfully on disk.");
			} catch (Exception e) {
				e.printStackTrace();
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
}
