package com.howtodoinjava.demo.jsonsimple;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;

public class ReadFullJson {

	public static void main(String[] args) {
		JSONParser jsonParser = new JSONParser();

		try (FileReader reader = new FileReader("Bp_Menu.json")) {
			Object obj = jsonParser.parse(reader);

			JSONArray array = (JSONArray) (((JSONObject) (((JSONObject) obj).get("body"))).get("items"));

			LinkedHashMap<String, String> mp=new LinkedHashMap<>();
			for (Object o : array) {
				String item = (String) ((JSONObject) o).get("id");
				JSONArray value = (JSONArray) ((JSONObject) ((JSONObject) ((JSONObject) o).get("taxLabelInfo"))
						.get("defaultValue")).get("labels");

				if (value.contains("TEMP_HEATED")) {
					mp.put(item, "TEMP_HEATED");
					
					//System.out.println(item + "======>" + "TEMP_HEATED");
				} else if (value.contains("TEMP_UNHEATED")) {
					mp.put(item, "TEMP_UNHEATED");
				//	System.out.println(item + "======>" + "TEMP_UNHEATED");
				} else if (value.contains("TEMP_COLD")) {
					mp.put(item, "TEMP_COLD");
				//	System.out.println(item + "======>" + "TEMP_COLD");
				} else {
					System.out.println(item + "======>" + "Nothing is found about TEMP");
				}

			}
			//System.out.println(mp);
			
			
			
			
			File inputFile2 = new File("tem.csv");
			@SuppressWarnings("deprecation")
			CSVReader reader2 = new CSVReader(new FileReader(inputFile2), ',');
			List<String[]> csvBody2 = reader2.readAll();

			int i=0;
			for (Map.Entry entry : mp.entrySet()) {
				csvBody2.get(i)[0]=(String)entry.getKey();
				csvBody2.get(i)[1]=(String)entry.getValue();	
				i++;
			}
			
			CSVWriter writer = new CSVWriter(new FileWriter("tem.csv"),
					',');
			writer.writeAll(csvBody2);
			writer.flush();
			writer.close();

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}
}
